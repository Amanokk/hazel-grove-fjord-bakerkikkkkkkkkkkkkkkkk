//#region node_modules/.nitro/vite/services/ssr/assets/catalog-Dpw3AA8E.js
/** Atividades extraídas dos diários G001 / APONTAMENTO das planilhas reais. */
var ACTIVITIES = [
	{
		id: "transp-equip-frente",
		name: "Transporte de equipamentos para frente de serviço",
		kind: "deslocamento"
	},
	{
		id: "preparo-calcada",
		name: "Preparo de calçada",
		kind: "servico"
	},
	{
		id: "exec-caixa-ralo",
		name: "Execução de caixa ralo",
		kind: "servico"
	},
	{
		id: "exec-ramal",
		name: "Execução de ramal",
		kind: "servico"
	},
	{
		id: "icamento-caixa-ralo",
		name: "Içamento de caixa ralo",
		kind: "servico"
	},
	{
		id: "icamento-ramal",
		name: "Içamento de ramal",
		kind: "servico"
	},
	{
		id: "alteamento-tampa",
		name: "Alteamento de tampa",
		kind: "servico"
	},
	{
		id: "espalh-bica-base",
		name: "Espalhamento de bica para base",
		kind: "servico"
	},
	{
		id: "espalh-bica-subbase",
		name: "Espalhamento de bica para sub-base",
		kind: "servico"
	},
	{
		id: "espalh-mat-subbase",
		name: "Espalhamento de material para sub-base",
		kind: "servico"
	},
	{
		id: "carreg-cam-bica",
		name: "Carregamento de caminhão de bica",
		kind: "servico"
	},
	{
		id: "carreg-cam-mat",
		name: "Carregamento de caminhão de material",
		kind: "servico"
	},
	{
		id: "descarga-aneis",
		name: "Descarga de anéis de concreto",
		kind: "servico"
	},
	{
		id: "descarga-tubos",
		name: "Descarga de tubos",
		kind: "servico"
	},
	{
		id: "demolicao-calcada",
		name: "Demolição de calçada",
		kind: "servico"
	},
	{
		id: "demolicao-emborcadura",
		name: "Demolição de emborcadura",
		kind: "servico"
	},
	{
		id: "limpeza-material",
		name: "Limpeza de material",
		kind: "servico"
	},
	{
		id: "org-canteiro",
		name: "Organização de material no canteiro",
		kind: "servico"
	},
	{
		id: "org-desague",
		name: "Limpeza e organização no deságue",
		kind: "servico"
	},
	{
		id: "escavacao",
		name: "Escavação",
		kind: "servico"
	},
	{
		id: "abertura-vala",
		name: "Abertura de vala",
		kind: "servico"
	},
	{
		id: "reaterro",
		name: "Reaterro",
		kind: "servico"
	},
	{
		id: "reaterro-escada",
		name: "Reaterro de escada hidráulica",
		kind: "servico"
	},
	{
		id: "reparo-erosao",
		name: "Reparo de erosão",
		kind: "servico"
	},
	{
		id: "reparo-esgoto",
		name: "Reparo de esgoto de morador",
		kind: "servico"
	},
	{
		id: "reparo-caixa-ralo",
		name: "Reparo de caixa ralo",
		kind: "servico"
	},
	{
		id: "troca-solo-borrachudo",
		name: "Troca de solo borrachudo",
		kind: "servico"
	},
	{
		id: "exec-drenagem",
		name: "Execução de drenagem",
		kind: "servico"
	},
	{
		id: "regularizacao-via",
		name: "Regularização da via",
		kind: "servico"
	},
	{
		id: "nivelamento",
		name: "Nivelamento",
		kind: "servico"
	},
	{
		id: "carreg-mat-subbase",
		name: "Carregamento de material para sub-base",
		kind: "servico"
	},
	{
		id: "carreg-mat-base",
		name: "Carregamento de material para base",
		kind: "servico"
	},
	{
		id: "carreg-bica-subbase",
		name: "Carregamento de bica para sub-base",
		kind: "servico"
	},
	{
		id: "carreg-bica-base",
		name: "Carregamento de bica para base",
		kind: "servico"
	},
	{
		id: "carreg-bica-caixa",
		name: "Carregamento de bica para caixa ralo",
		kind: "servico"
	},
	{
		id: "carreg-reg-subleito",
		name: "Carregamento de material de regularização de subleito",
		kind: "servico"
	},
	{
		id: "carreg-borrachudo",
		name: "Carregamento de material borrachudo",
		kind: "servico"
	},
	{
		id: "transp-metalon",
		name: "Transporte de metalon",
		kind: "servico"
	},
	{
		id: "atendendo-outra-obra",
		name: "Atendendo outra obra",
		kind: "deslocamento"
	},
	{
		id: "umid-subbase",
		name: "Umidificação de sub-base",
		kind: "servico"
	},
	{
		id: "umid-base",
		name: "Umidificação de base",
		kind: "servico"
	},
	{
		id: "abast-frente",
		name: "Abastecimento da frente de serviço",
		kind: "servico"
	},
	{
		id: "molhar-pedreira",
		name: "Molhar acessos da pedreira",
		kind: "servico"
	},
	{
		id: "abast-agua",
		name: "Abastecer caminhão com água",
		kind: "deslocamento"
	},
	{
		id: "prevencao-poeira",
		name: "Prevenção de poeira",
		kind: "servico"
	},
	{
		id: "transp-colab-ida",
		name: "Transporte de colaboradores Itaguaí → São Joaquim",
		kind: "servico"
	},
	{
		id: "transp-colab-volta",
		name: "Transporte de colaboradores São Joaquim → Itaguaí",
		kind: "servico"
	},
	{
		id: "transp-colab-marambaia",
		name: "Transporte de colaboradores Marambaia",
		kind: "servico"
	},
	{
		id: "recolhe-campo",
		name: "Recolher colaboradores no campo",
		kind: "servico"
	},
	{
		id: "recolhe-almoco",
		name: "Recolher colaboradores para almoço",
		kind: "servico"
	},
	{
		id: "transp-frente-colab",
		name: "Transporte de colaboradores para frente de serviço",
		kind: "servico"
	},
	{
		id: "transp-exame",
		name: "Transporte para exame médico",
		kind: "servico"
	},
	{
		id: "estacionada",
		name: "Canteiro — estacionada",
		kind: "status"
	},
	{
		id: "comp-subleito",
		name: "Compactação de subleito",
		kind: "servico"
	},
	{
		id: "comp-subbase",
		name: "Compactação de sub-base",
		kind: "servico"
	},
	{
		id: "comp-base",
		name: "Compactação de base",
		kind: "servico"
	},
	{
		id: "comp-solo",
		name: "Compactação de solo",
		kind: "servico"
	},
	{
		id: "comp-reparo-erosao",
		name: "Compactação após reparo de erosão",
		kind: "servico"
	},
	{
		id: "comp-apos-pv",
		name: "Compactação após execução de PV",
		kind: "servico"
	},
	{
		id: "foi-frente",
		name: "Foi para frente de serviço",
		kind: "deslocamento"
	},
	{
		id: "voltou-canteiro",
		name: "Voltou ao canteiro",
		kind: "deslocamento"
	},
	{
		id: "puxada-material",
		name: "Puxada de material",
		kind: "servico"
	},
	{
		id: "puxada-drenagem",
		name: "Puxada de material para drenagem",
		kind: "servico"
	},
	{
		id: "puxada-pulmao",
		name: "Puxada de material para pulmão da obra",
		kind: "servico"
	},
	{
		id: "transp-material",
		name: "Transporte de material",
		kind: "servico"
	},
	{
		id: "chegou-canteiro",
		name: "Chegou ao canteiro",
		kind: "deslocamento"
	},
	{
		id: "saiu-manutencao",
		name: "Saiu da manutenção",
		kind: "deslocamento"
	},
	{
		id: "a-disposicao",
		name: "À disposição",
		kind: "status",
		code: "C4"
	},
	{
		id: "aguard-frente",
		name: "À disposição — aguardando frente",
		kind: "status",
		code: "C1"
	},
	{
		id: "aguard-material",
		name: "Aguardando materiais",
		kind: "status",
		code: "C2"
	},
	{
		id: "em-manutencao",
		name: "Em manutenção",
		kind: "status",
		code: "B4"
	},
	{
		id: "problema-mec",
		name: "Problema mecânico",
		kind: "status",
		code: "B3"
	},
	{
		id: "pneu-furado",
		name: "Pneu furado",
		kind: "status",
		code: "B1"
	},
	{
		id: "tempo-chuvoso",
		name: "Tempo chuvoso",
		kind: "status",
		code: "A1"
	},
	{
		id: "solo-saturado",
		name: "Solo saturado — impraticável",
		kind: "status",
		code: "A1"
	},
	{
		id: "motorista-ausente",
		name: "Motorista / operador ausente",
		kind: "status",
		code: "C6"
	},
	{
		id: "falta-operador",
		name: "Falta de operador",
		kind: "status",
		code: "C6"
	}
];
var RETRO = [
	"transp-equip-frente",
	"preparo-calcada",
	"exec-caixa-ralo",
	"exec-ramal",
	"icamento-caixa-ralo",
	"icamento-ramal",
	"alteamento-tampa",
	"espalh-bica-base",
	"espalh-bica-subbase",
	"espalh-mat-subbase",
	"carreg-cam-bica",
	"carreg-cam-mat",
	"descarga-aneis",
	"descarga-tubos",
	"demolicao-calcada",
	"demolicao-emborcadura",
	"limpeza-material",
	"org-canteiro",
	"org-desague",
	"escavacao",
	"abertura-vala",
	"reaterro",
	"reaterro-escada",
	"reparo-erosao",
	"reparo-esgoto",
	"reparo-caixa-ralo",
	"troca-solo-borrachudo",
	"exec-drenagem",
	"regularizacao-via",
	"nivelamento",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"tempo-chuvoso",
	"solo-saturado",
	"falta-operador"
];
var BASCULANTE = [
	"carreg-mat-subbase",
	"carreg-mat-base",
	"carreg-bica-subbase",
	"carreg-bica-base",
	"carreg-bica-caixa",
	"carreg-reg-subleito",
	"carreg-borrachudo",
	"transp-metalon",
	"atendendo-outra-obra",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"pneu-furado",
	"tempo-chuvoso",
	"solo-saturado",
	"motorista-ausente"
];
var PIPA = [
	"umid-subbase",
	"umid-base",
	"abast-frente",
	"molhar-pedreira",
	"abast-agua",
	"prevencao-poeira",
	"atendendo-outra-obra",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"tempo-chuvoso",
	"motorista-ausente"
];
var VAN = [
	"transp-colab-ida",
	"transp-colab-volta",
	"transp-colab-marambaia",
	"recolhe-campo",
	"recolhe-almoco",
	"transp-frente-colab",
	"transp-exame",
	"estacionada",
	"chegou-canteiro",
	"saiu-manutencao",
	"a-disposicao",
	"em-manutencao",
	"tempo-chuvoso",
	"motorista-ausente"
];
var ROLO = [
	"comp-subleito",
	"comp-subbase",
	"comp-base",
	"comp-solo",
	"comp-reparo-erosao",
	"comp-apos-pv",
	"foi-frente",
	"voltou-canteiro",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"problema-mec",
	"tempo-chuvoso",
	"solo-saturado"
];
var TRUCK = [
	"puxada-material",
	"puxada-drenagem",
	"puxada-pulmao",
	"transp-material",
	"regularizacao-via",
	"carreg-mat-subbase",
	"carreg-bica-subbase",
	"chegou-canteiro",
	"a-disposicao",
	"aguard-frente",
	"em-manutencao",
	"pneu-furado",
	"tempo-chuvoso",
	"motorista-ausente"
];
var EQUIPMENT = [
	{
		id: "lok-453",
		code: "LOK 453",
		name: "Retroescavadeira LOK 453",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "lok-457",
		code: "LOK 457",
		name: "Retroescavadeira LOK 457",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "lye-200",
		code: "LYE 200",
		name: "Retroescavadeira LYE 200",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "loc-204",
		code: "LOC 204",
		name: "Retroescavadeira CASE 580N LOC 204",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "loc-304",
		code: "LOC 304",
		name: "Retroescavadeira John Deere LOC 304",
		kind: "retro",
		activityIds: RETRO,
		active: true
	},
	{
		id: "loc-073",
		code: "LOC 073",
		name: "Rolo Compactador LOC 073",
		kind: "rolo",
		activityIds: ROLO,
		active: true
	},
	{
		id: "lyc-154",
		code: "LYC 154",
		name: "Caminhão Traçado LYC 154",
		kind: "basculante",
		activityIds: BASCULANTE,
		active: true
	},
	{
		id: "lyc-317",
		code: "LYC 317",
		name: "Caminhão Traçado LYC 317",
		kind: "basculante",
		activityIds: BASCULANTE,
		active: true
	},
	{
		id: "lyc-025",
		code: "LYC 025",
		name: "Caminhão Pipa LYC 025",
		kind: "pipa",
		activityIds: PIPA,
		active: true
	},
	{
		id: "lyc-303",
		code: "LYC 303",
		name: "Van Sprinter LYC 303",
		kind: "van",
		activityIds: VAN,
		active: true
	},
	{
		id: "lqo0b03",
		code: "LQO0B03",
		name: "Caminhão Truck LQO0B03",
		kind: "truck",
		activityIds: TRUCK,
		active: true
	},
	{
		id: "loc-232",
		code: "LOC 232",
		name: "Caminhão Cachorreira LLT2H91 LOC 232",
		kind: "truck",
		activityIds: TRUCK,
		active: true
	},
	{
		id: "loc-799",
		code: "LOC 799",
		name: "Caminhão Toco LOC 799",
		kind: "truck",
		plate: "LAR5861",
		activityIds: TRUCK,
		active: true
	}
];
var WORKS = [
	{
		id: "l449",
		code: "L449",
		name: "São Joaquim",
		active: true
	},
	{
		id: "l442",
		code: "L442",
		name: "Miguel Pereira",
		active: true
	},
	{
		id: "l389",
		code: "L389",
		name: "Amaro Cavalcante",
		active: true
	},
	{
		id: "l388",
		code: "L388",
		name: "São Domingos Sávio",
		active: true
	},
	{
		id: "l513",
		code: "L513",
		name: "Pedreira",
		active: true
	}
];
var STREETS = [
	{
		id: "visconde",
		name: "Rua Visconde de Itaboraí",
		workId: "l449",
		active: true
	},
	{
		id: "augusto",
		name: "Rua Pref. Augusto de Andrade",
		workId: "l449",
		active: true
	},
	{
		id: "alberto",
		name: "Rua Alberto Torres",
		workId: "l449",
		active: true
	},
	{
		id: "jose-leandro",
		name: "Rua José Leandro",
		workId: "l449",
		active: true
	},
	{
		id: "joao-caetano",
		name: "Rua João Caetano",
		workId: "l449",
		active: true
	},
	{
		id: "margaridas",
		name: "Rua das Margaridas",
		workId: "l388",
		active: true
	},
	{
		id: "hermes",
		name: "Travessa Hermes",
		workId: "l388",
		active: true
	},
	{
		id: "sao-domingos",
		name: "Rua São Domingos Sávio",
		workId: "l388",
		active: true
	},
	{
		id: "uva",
		name: "Rua Uva",
		workId: "l388",
		active: true
	},
	{
		id: "jerusalem",
		name: "Rua Jerusalém",
		workId: "l388",
		active: true
	}
];
var KIND_LABEL = {
	retro: "Retroescavadeira",
	rolo: "Rolo compactador",
	basculante: "Caminhão traçado",
	pipa: "Caminhão pipa",
	van: "Van / transporte",
	truck: "Caminhão"
};
var QUANTITY_LABEL = {
	basculante: "Viagens",
	truck: "Viagens",
	pipa: "Cargas de água",
	retro: "Viagens carregadas"
};
var PV_PREFIXES = [
	"PVD",
	"PVC",
	"PVE",
	"PV",
	"PVA"
];
var NOTE_CHIPS = [
	"Tempo chuvoso",
	"Solo saturado",
	"Aguardando frente de serviço",
	"Motorista ausente",
	"Saiu da manutenção",
	"Chegou ao canteiro"
];
//#endregion
export { PV_PREFIXES as a, WORKS as c, NOTE_CHIPS as i, EQUIPMENT as n, QUANTITY_LABEL as o, KIND_LABEL as r, STREETS as s, ACTIVITIES as t };
